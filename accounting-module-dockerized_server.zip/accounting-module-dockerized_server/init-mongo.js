db.createUser(
    {
        user:"admin",
        pwd: "chompbtc",
        roles:[
            {
                role:"readWrite",
                db: "TEST"
            }
        ]

    }
)