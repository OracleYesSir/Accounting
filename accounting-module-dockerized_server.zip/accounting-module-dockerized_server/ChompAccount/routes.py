def setup_routes(app, handler, project_root):
    router = app.router
    h = handler
    router.add_get('/', h.hello, name='timeline')
    
    router.add_post('/paxful',h.getPaxfulTransaction, name='getPaxfulTransaction')

    router.add_post('/fireblocks',h.getFireBlocksTransaction, name='getFireBlocksTransaction')
    
