from ChompAccount.main import main

main()
