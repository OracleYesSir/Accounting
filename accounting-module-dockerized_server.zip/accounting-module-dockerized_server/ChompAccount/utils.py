import os
from hashlib import md5
import redis
import motor.motor_asyncio as aiomotor
import pytz
import yaml
from aiohttp import web
from dateutil.parser import parse
import redis
from . import db


def load_config(fname):
    with open(fname, 'rt') as f:
        data = yaml.load(f)
    # TODO: add config validation
    return data


async def init_mongo(conf, loop):
    host = os.environ.get('DOCKER_MACHINE_IP', '127.0.0.1')
    conf['host'] = host

    mongo_uri = "mongodb://{}:{}@{}:{}".format(conf['user'],conf['password'],conf['host'], conf['port'])
    print(mongo_uri)
    conn = aiomotor.AsyncIOMotorClient(
        mongo_uri,
        maxPoolSize=conf['max_pool_size'],
        io_loop=loop)
    db_name = conf['database']
    return conn[db_name]

def load_Redis():
    return redis.Redis(host='redis', port=6379, db=0)



def format_datetime(timestamp):
    if isinstance(timestamp, str):
        timestamp = parse(timestamp)
    return timestamp.replace(tzinfo=pytz.utc).strftime('%Y-%m-%d @ %H:%M')




def filterPaxfulPost(jsonObject):
    return

def filterFireBlocksPost(jsonObject):   
    return