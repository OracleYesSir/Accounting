import asyncio
import logging
import pathlib


from aiohttp import web
from aiohttp_security import setup as setup_security
from aiohttp_security import CookiesIdentityPolicy
from ChompAccount.handlers import Handler
from ChompAccount.routes import setup_routes
from ChompAccount.security import AuthorizationPolicy
from ChompAccount.utils import (format_datetime, init_mongo, load_config
                            ,load_Redis)



PROJ_ROOT = pathlib.Path(__file__).parent.parent
TEMPLATES_ROOT = pathlib.Path(__file__).parent / 'templates'


async def setup_mongo(app, conf, loop):
    mongo = await init_mongo(conf['mongo'], loop)

    async def close_mongo(app):
        mongo.client.close()

    app.on_cleanup.append(close_mongo)
    return mongo





async def init(loop):
    print("starting server")
    conf = load_config(PROJ_ROOT / 'config' / 'config.yml')

    app = web.Application(loop=loop)
    mongo = await setup_mongo(app, conf, loop)
    redis =load_Redis()
    
    setup_security(app, CookiesIdentityPolicy(), AuthorizationPolicy(mongo))

    # setup views and routes
    handler = Handler(mongo,redis)
    setup_routes(app, handler, PROJ_ROOT)
    host, port = conf['host'], conf['port']
    return app, host, port


def main():
    logging.basicConfig(level=logging.DEBUG)
    print("starting main")
    loop = asyncio.get_event_loop()
    app, host, port = loop.run_until_complete(init(loop))
    ##web.run_app(app, host=host, port=port)
    return app


if __name__ == '__main__':
    main()

app = main()