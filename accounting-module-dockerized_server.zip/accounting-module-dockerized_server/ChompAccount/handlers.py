from aiohttp import web
class Handler:

    def __init__(self, mongo,redis):
        self._mongo = mongo
        self._redis=redis
    @property

    def mongo(self):
        return self._mongo
    def redis(self):
        return self._redis

    async def getPaxfulTransaction(self,request):
        
        data=await request.json()
        
        print(data['transactionHash'])
        print(self._redis)
        query=data['transactionHash']+"paxful"
        query2=data['transactionHash']+"fireblocks"
        print(query2)
        exist=self._redis.get(query2)
        print(exist)
        self._redis.set( query,data['data'])
        if(exist):
           
            print("activating filtering")
        return  web.Response(text="OK")
       
        
       


    async def getFireBlocksTransaction(self,request):
        data=await request.json()
        
        print(data['transactionHash'])
        print(self._redis)
        query=data['transactionHash']+"paxful"
        query2=data['transactionHash']+"fireblocks"
        self._redis.set( query2,data['data'])
        exist=self._redis.get(query)
        if(exist):
            
            print("activating filtering")
        return  web.Response(text="OK")
        
    def hello(self):
        return "hello"




    














